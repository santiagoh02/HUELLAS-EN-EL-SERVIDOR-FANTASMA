const mazoEspadasASCII = [
  'A♠', '2♠', '3♠', '4♠', '5♠', '6♠', '7♠', '8♠', '9♠', '10♠', 'J♠', 'Q♠', 'K♠'
];

/**
 * @param {Array} deck 
 * @returns {number} 
 * @throws {TypeError} 
 */
const getFirstEvenCardPosition = (deck) => {
  if (!Array.isArray(deck)) throw new TypeError("deck debe ser un arreglo");

  return deck.findIndex(card => {
    if (typeof card === 'string') {
      if (card.startsWith('A')) return false;
      if (card.startsWith('J')) return false;
      if (card.startsWith('Q')) return true; 
      if (card.startsWith('K')) return false; 

      const number = parseInt(card.substring(0, card.length - 1));
      return number % 2 === 0;
    }

    if (typeof card === 'number') {
      return card % 2 === 0;
    }

    throw new TypeError("Cada carta debe ser un número o una cadena de texto");
  });
};

console.log(getFirstEvenCardPosition([5, 2, 3, 1]));        
console.log(getFirstEvenCardPosition(['A♠', '2♠', '3♠']));
console.log(getFirstEvenCardPosition(['A♠', 'J♠', 'K♠']));
console.log(getFirstEvenCardPosition(mazoEspadasASCII)); 