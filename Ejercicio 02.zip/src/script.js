const mazoEspadasASCII = [
  'A♠', '2♠', '3♠', '4♠', '5♠', '6♠', '7♠', '8♠', '9♠', '10♠', 'J♠', 'Q♠', 'K♠'
];

/**
 * @param {Array} deck 
 * @param {*} card 
 * @returns {boolean} 
 */
const findCard = (deck, card) => {
  if (!Array.isArray(deck)) throw new TypeError('deck debe ser un arreglo');
  return deck.includes(card);
};

// Ejemplos:
console.log(findCard(mazoEspadasASCII, 'A♠'));  
console.log(findCard(mazoEspadasASCII, 'J♥')); 